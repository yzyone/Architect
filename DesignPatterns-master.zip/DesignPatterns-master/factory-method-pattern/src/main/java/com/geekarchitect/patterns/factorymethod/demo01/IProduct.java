package com.geekarchitect.patterns.factorymethod.demo01;

/**
 * @author 极客架构师@吴念
 * @createTime 2022/6/13
 */
public interface IProduct {
    void doService();
}
