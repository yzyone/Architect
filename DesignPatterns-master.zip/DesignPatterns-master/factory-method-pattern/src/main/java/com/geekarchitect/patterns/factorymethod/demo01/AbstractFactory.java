package com.geekarchitect.patterns.factorymethod.demo01;

/**
 * 抽象工厂：抽象类
 *
 * @author 极客架构师@吴念
 * @createTime 2022/6/22
 */
public abstract class AbstractFactory implements IFactory {
}
