package com.geekarchitect.patterns.factorymethod.demo02;

/**
 * @author 极客架构师@吴念
 * @createTime 2022/6/13
 */
public interface IProductA {
    void doService();
}
