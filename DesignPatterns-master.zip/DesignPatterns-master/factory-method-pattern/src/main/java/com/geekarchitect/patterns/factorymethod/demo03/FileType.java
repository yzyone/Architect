package com.geekarchitect.patterns.factorymethod.demo03;

public enum FileType {
    EXCEL_2003, EXCEL_2007
}
