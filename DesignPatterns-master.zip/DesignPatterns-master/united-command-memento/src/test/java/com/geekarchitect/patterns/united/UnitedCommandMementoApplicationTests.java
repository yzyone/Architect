package com.geekarchitect.patterns.united;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UnitedCommandMementoApplicationTests {

    @Test
    void contextLoads() {
    }

}
