package com.geekarchitect.patterns.cor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CorApplicationTests {

    @Test
    void contextLoads() {
    }

}
