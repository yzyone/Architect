package com.geekarchitect.patterns.cor.demo02;

import lombok.Data;

/**
 * 营销活动
 * @author 极客架构师@吴念
 * @createTime 2022/9/16
 */
@Data
public class Activity {
    private Long id;
}
