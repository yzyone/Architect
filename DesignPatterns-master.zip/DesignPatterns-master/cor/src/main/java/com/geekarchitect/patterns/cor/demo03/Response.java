package com.geekarchitect.patterns.cor.demo03;

import lombok.Data;

/**
 * @author 极客架构师@吴念
 * @createTime 2022/9/16
 */
@Data
public class Response {
    private Boolean isOk;
}
