package com.geekarchitect.patterns.cor.demo01;

/**
 * 处理结果角色
 *
 * @author 极客架构师@吴念
 * @createTime 2022/9/15
 */
public class Response {
}
