package com.geekarchitect.patterns.cor.demo01;

/**
 * 请求角色
 *
 * @author 极客架构师@吴念
 * @createTime 2022/9/15
 */
public class Request {

}
