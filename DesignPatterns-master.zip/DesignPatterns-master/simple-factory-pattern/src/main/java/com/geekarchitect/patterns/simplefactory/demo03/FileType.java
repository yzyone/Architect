package com.geekarchitect.patterns.simplefactory.demo03;

public enum FileType {
    EXCEL_2003,EXCEL_2007;
}
