package com.geekarchitect.patterns.simplefactory.demo01;

public enum ProductType {
    PRODUCT_A,PRODUCT_B;
}
