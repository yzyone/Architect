package com.geekarchitect.patterns.memento.demo02;

/**
 * 快照接口
 * 备忘录角色：Memento role
 *
 * @author 极客架构师@吴念
 * @createTime 2022/9/6
 */
public interface ISnapshot {
}
