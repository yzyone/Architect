package com.geekarchitect.patterns.memento.demo01;

/**
 * 备忘录角色接口：无需任何方法
 * @author 极客架构师@吴念
 * @createTime 2022/9/6
 */
public interface IMementoRole {
}
