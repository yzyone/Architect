package com.geekarchitect.patterns.command.demo03;

/**
 * @author 极客架构师@吴念
 * @createTime 2022/8/29
 */
public interface IDegradeServiceV2 {
    void offline(int appCode);
}
