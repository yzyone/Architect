package com.geekarchitect.patterns.command.demo02;

/**
 * @author 极客架构师@吴念
 * @createTime 2022/8/29
 */
public interface IDegradeService {
    void offline(int appCode);
}
