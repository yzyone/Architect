package com.geekarchitect.patterns.command.demo04;

/**
 * @author 极客架构师@吴念
 * @createTime 2022/8/29
 */
public interface IDegradeServiceV3 {
    void offline(int appCode);
}
