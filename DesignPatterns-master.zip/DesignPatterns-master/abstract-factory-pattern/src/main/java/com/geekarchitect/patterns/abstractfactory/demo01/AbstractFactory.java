package com.geekarchitect.patterns.abstractfactory.demo01;

/**
 * @author 极客架构师@吴念
 * @createTime 2022/6/22
 */
public abstract class AbstractFactory implements IFactory {
}
