package com.geekarchitect.patterns.abstractfactory.demo02;

import java.util.List;

/**
 * 具体产品
 *
 * @author 极客架构师@吴念
 * @createTime 2022/6/13
 */
public class RussiaExcel2007Export implements IExcelExport {
    public void exportExcel(List<SKU> skuList) {
    }
}
