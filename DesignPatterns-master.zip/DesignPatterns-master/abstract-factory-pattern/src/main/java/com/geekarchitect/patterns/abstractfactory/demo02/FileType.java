package com.geekarchitect.patterns.abstractfactory.demo02;

public enum FileType {
    CHINA_EXCEL_2003, CHINA_EXCEL_2007, RUSSIA_EXCEL_2003, RUSSIA_EXCEL_2007,
    CHINA_MYSQL, CHINA_ORACLE, RUSSIA_MYSQL, RUSSIA_ORACLE
}
