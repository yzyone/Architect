package com.geekarchitect.patterns.demo0101;

/**
 * 结算服务接口
 *
 * @author 极客架构师@吴念
 * @createTime 2022/3/24
 */
public interface ISettlementService {
    void settlement(Cart cart);
}
