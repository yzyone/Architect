package com.geekarchitect.patterns.builder.demo05;

/**
 * @author 极客架构师@吴念
 * @createTime 2022/8/1
 */
public class TestDubbo {
    public static void main(String[] args) {

    }
    public void demo01(){

    }
}
