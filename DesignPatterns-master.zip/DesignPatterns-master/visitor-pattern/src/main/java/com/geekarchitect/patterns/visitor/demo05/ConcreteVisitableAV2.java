package com.geekarchitect.patterns.visitor.demo05;

/**
 * @author 极客架构师@吴念
 * @createTime 2022/11/2
 */
public class ConcreteVisitableAV2 implements IVisitableV2 {

    @Override
    public String getVisitableInfo() {
        return "ConcreteVisitableAV2";
    }

}
