package com.geekarchitect.patterns.visitor.demo01;

public enum CloudFileType {
    DIR, TXT, IMG, ZIP
}
