package com.geekarchitect.patterns.demo0204;

public enum StateEnum {
    STATE01, STATE02
}
