package com.geekarchitect.patterns.prototype.demo01;

/**
 * @author 极客架构师@吴念
 * @createTime 2022/7/18
 */
public interface IProduct extends Cloneable{

}
